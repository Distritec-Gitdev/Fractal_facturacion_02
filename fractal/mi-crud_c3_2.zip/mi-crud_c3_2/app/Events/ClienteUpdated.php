<?php

// app/Events/ClienteUpdated.php
namespace App\Events;

use App\Models\Cliente;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ClienteUpdated implements ShouldBroadcast
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $cliente;

    public function __construct(Cliente $cliente)
    {
        $this->cliente = $cliente;
    }

    public function broadcastOn()
    {
        return new Channel('cliente'); // Cambia el nombre del canal
    }

    public function broadcastAs()
    {
        return 'ClienteUpdated'; // Nombre único para el evento
    }
}