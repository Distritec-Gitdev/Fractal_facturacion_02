<?php

namespace App\Filament\Resources;

use App\Filament\Resources\ClienteResource\Pages;
use App\Models\Cliente;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Repeater;
use App\Models\ZMarca;
use App\Models\ZModelo;
use App\Models\ZGarantia;
use App\Models\ZPago;
use App\Models\ZParentescoPersonal;
use App\Models\ZTiempoConocerloNum;
use App\Models\ZTiempoConocerlo;
use App\Models\ZPlataformaCredito;
use App\Models\ZComision;
use App\Models\InfTrab;
use App\Models\ZPdvAgenteDistritec;
use App\Models\ZDepartamentos;
use App\Models\ZMunicipios;

class ClienteResource extends Resource
{
    protected static ?string $model = Cliente::class;
    protected static ?string $navigationIcon = 'heroicon-o-users';
    protected static ?string $navigationGroup = 'Gestión Clientes';
    protected static ?string $modelLabel = 'Cliente';
    protected static ?string $pluralModelLabel = 'Clientes';



    public static function form(Form $form): Form
{
    return $form
        ->schema([
            Forms\Components\TextInput::make('cedula')
            ->label('Cédula')
            ->required()
            ->numeric()
            ->mask('9999999999') // Máscara visual
            ->maxLength(10) // Protección extra a nivel de atributo
            ->extraAttributes([
                'class' => 'text-lg font-bold',
                'oninput' => <<<JS
                    const raw = this.value;
                    const digitsOnly = raw.replace(/\\D/g, '');
                    if (digitsOnly.length > 10) {
                        let digitCount = 0;
                        let result = '';
                        for (let char of raw) {
                            if (/\\d/.test(char)) digitCount++;
                            if (digitCount > 10) break;
                            result += char;
                        }
                        this.value = result;
                    }
                JS,
            ])
            ->rule('regex:/^[\d\s]+$/') // Valida solo números y espacios
            ->validationMessages([
                'max_length' => 'Máximo 10 dígitos permitidos.',
                'regex' => 'Solo se permiten números y espacios.',
            ]),
        
            DatePicker::make('fecha_nac')
                ->label('Fecha de Nacimiento')
                ->required()
                ->displayFormat('d/m/Y') // Formato de visualización (opcional)
                ->native(false)
                ->format('Y-m-d')
                ->rules([
                    'date',
                    'before:today', // Solo fechas pasadas
                ])
                ->placeholder('Selecciona una fecha'),
             
                Select::make('id_departamento')
                     ->label('Departamento Expedicion Documento') 
                     ->required()
                     ->options(
                         // Obtener todas las marcas de z_marca
                         ZDepartamentos::all()->pluck('name_departamento', 'id')
                     )
                     ->searchable()
                     ->preload(),

                     Select::make('id_municipio')
                     ->label('Municipio Expedicion Documento') 
                     ->required()
                     ->options(
                         // Obtener todas las marcas de z_marca
                         ZMunicipios::all()->pluck('name_municipio', 'id')
                     )
                     ->searchable()
                     ->preload(),

            
            
            // Campo oculto para ID_Cliente_Nombre (si es necesario)
            Forms\Components\Hidden::make('ID_Cliente_Nombre'),
            
            // Sección para nombres y apellidos (relación)
            Forms\Components\Section::make('Nombres y Apellidos')
                ->relationship('clientesNombreCompleto') // 👈 Indica la relación
                ->columns(3)
                ->schema([
                    Forms\Components\TextInput::make('Primer_nombre_cliente')
                        ->label('Primer Nombre')
                        ->required()
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                    
                    Forms\Components\TextInput::make('Segundo_nombre_cliente')
                        ->label('Segundo Nombre')
                        ->required()
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        
                    Forms\Components\TextInput::make('Primer_apellido_cliente')
                        ->label('Primer Apellido')
                        ->required()
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        
                    Forms\Components\TextInput::make('Segundo_apellido_cliente')
                        ->label('Segundo Apellido')
                        ->required()
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),

                        
               
                ]),

             // Sección para nombres y apellidos (relación)
             Forms\Components\Section::make('Contactos')
             ->relationship('ClientesContacto') // 👈 Indica la relación
             ->columns(3)
             ->schema([
                 Forms\Components\TextInput::make('correo')
                     ->label('Correo electrónico')
                     ->required(),
                     
                 Forms\Components\TextInput::make('tel')
                 ->label('Teléfono')
                 ->required()
                 ->maxLength(14) // Hasta 10 dígitos + espacios
                 ->extraInputAttributes([
                     // Mientras escribe, limita a 10 dígitos sin espacios
                     'oninput' => "this.value = this.value.replace(/\\D/g, '').slice(0,10);",
                     // Al perder foco, formatea con espacios: 123 456 7890
                     'onblur' => "let d=this.value.replace(/\\D/g,'').slice(0,10); let f=''; if(d.length>0) f=d.substr(0,3); if(d.length>3) f+=' '+d.substr(3,3); if(d.length>6) f+=' '+d.substr(6); this.value=f;",
                 ])
                 ->rule('regex:/^[\d ]{0,14}$/') // Solo dígitos y espacios
                 ->validationMessages([
                     'regex' => 'Solo se permiten números y espacios.',
                     'max_length' => 'Máximo 10 dígitos permitidos.',
                 ]),
             
                 Forms\Components\TextInput::make('tel_alternativo')
                     ->label('Teléfono Alterno')
                     ->required()
                     ->maxLength(14) // Hasta 10 dígitos + espacios
                     ->extraInputAttributes([
                         // Mientras escribe, limita a 10 dígitos sin espacios
                         'oninput' => "this.value = this.value.replace(/\\D/g, '').slice(0,10);",
                         // Al perder foco, formatea con espacios: 123 456 7890
                         'onblur' => "let d=this.value.replace(/\\D/g,'').slice(0,10); let f=''; if(d.length>0) f=d.substr(0,3); if(d.length>3) f+=' '+d.substr(3,3); if(d.length>6) f+=' '+d.substr(6); this.value=f;",
                     ])
                     ->rule('regex:/^[\d ]{0,14}$/') // Solo dígitos y espacios
                     ->validationMessages([
                         'regex' => 'Solo se permiten números y espacios.',
                         'max_length' => 'Máximo 10 dígitos permitidos.',
                     ]),
                 
                 Forms\Components\TextInput::make('direccion')
                     ->label('Dirección')
                     ->required(),

                 Select::make('residencia_id_departamento')
                     ->label('Departamento Residencia') 
                     ->required()
                     ->options(
                         // Obtener todas las marcas de z_marca
                         ZDepartamentos::all()->pluck('name_departamento', 'id')
                     )
                     ->searchable()
                     ->preload(),

                 Select::make('residencia_id_municipio')
                     ->label('Municipio Residencia') 
                     ->required()
                     ->options(
                         // Obtener todas las marcas de z_marca
                         ZMunicipios::all()->pluck('name_municipio', 'id')
                     )
                     ->searchable()
                     ->preload(),

          
                     
                
             ]),

               // Sección para dispositivos comprados (relación)
               Forms\Components\Section::make('Dispositivos Comprados')
               ->schema([
                   Repeater::make('dispositivosComprados') // 👈 Nombre de la relación hasMany
                       ->relationship()
                       ->schema([
                           Select::make('id_marca')
                               ->label('Marca del Dispositivo')
                               ->required()
                               ->options(
                                   // Obtener todas las marcas de z_marca
                                   ZMarca::all()->pluck('name_marca', 'idmarca')
                               )
                               ->searchable()
                               ->preload(),

                           Select::make('idmodelo')
                               ->label('Modelo del Dispositivo')
                               ->required()
                               ->options(
                                   // Obtener todos los modelos
                                   ZModelo::all()->pluck('name_modelo', 'idmodelo')
                               )
                               ->searchable()
                               ->preload(),

                           Select::make('idgarantia')
                               ->label('Garantía')
                               ->required()
                               ->options(
                                   // Obtener todos los modelos
                                   ZGarantia::all()->pluck('garantia', 'idgarantia')
                               )
                               ->searchable()
                               ->preload(),
                               Forms\Components\TextInput::make('imei')
                               ->label('IMEI')
                               ->required()
                               ->rule('regex:/^[A-Za-z0-9]+$/') // Solo caracteres alfanuméricos
                               ->extraInputAttributes([
                                   // Elimina caracteres no alfanuméricos al escribir
                                   'oninput' => "this.value = this.value.replace(/[^A-Za-z0-9]/g, '');",
                                   // Previene pegar caracteres especiales
                                   'onpaste' => "event.preventDefault();",
                                   // Patrón HTML para bloqueo adicional en navegadores
                                   'pattern' => '[A-Za-z0-9]+'
                               ])
                               ->validationMessages([
                                   'regex' => 'No se permiten caracteres especiales.',
                               ]),
                            
                    
                       ])
                       ->columns(3)
                       ->disableItemCreation() // 👈 Opcional: Bloquear nuevos elementos
                       ->disableItemDeletion() ,// 👈 Opcional: Bloquear eliminación
                       
                               ]),
    

              // Sección para dispositivos comprados (relación)
              Forms\Components\Section::make('Informacón de pago')
              ->schema([
                  Repeater::make('dispositivosPago') // 👈 Nombre de la relación hasMany
                      ->relationship()
                      ->schema([

                         DatePicker::make('fecha_pc')
                            ->label('Fecha Primer Cuota')
                            ->required()
                            ->displayFormat('d/m/Y') // Formato de visualización (opcional)
                            ->native(false)
                            ->format('Y-m-d'),
                         
                          Select::make('idpago')
                              ->label('Periodo de Pago')
                              ->required()
                              ->options(
                                  // Obtener todas las marcas de z_marca
                                  ZPago::all()->pluck('periodo_pago', 'idpago')
                              )
                              ->searchable()
                              ->preload(),

                           
                           Forms\Components\TextInput::make('cuota_inicial')
                           ->label('Cuota Inicial')
                           ->required()
                           ->extraInputAttributes([
                               // Formatea con punto cada 3 dígitos en oninput y onblur
                               'oninput' => "let v=this.value.replace(/\D/g,''); let parts=[]; while(v.length>3){ parts.unshift(v.slice(-3)); v=v.slice(0,-3);} if(v) parts.unshift(v); this.value=parts.join('.');",
                               'onblur'  => "let v=this.value.replace(/\D/g,''); let parts=[]; while(v.length>3){ parts.unshift(v.slice(-3)); v=v.slice(0,-3);} if(v) parts.unshift(v); this.value=parts.join('.');",
                           ])
                           ->rule('numeric') // Valida que solo haya números
                           ->validationMessages([
                               'numeric' => 'Debe ser un número válido.',
                           ]),
                           Forms\Components\TextInput::make('num_cuotas'),
                           Forms\Components\TextInput::make('valor_cuotas')    ->label('Cuota Inicial')
                           ->required()
                           ->extraInputAttributes([
                               // Formatea con punto cada 3 dígitos en oninput y onblur
                               'oninput' => "let v=this.value.replace(/\D/g,''); let parts=[]; while(v.length>3){ parts.unshift(v.slice(-3)); v=v.slice(0,-3);} if(v) parts.unshift(v); this.value=parts.join('.');",
                               'onblur'  => "let v=this.value.replace(/\D/g,''); let parts=[]; while(v.length>3){ parts.unshift(v.slice(-3)); v=v.slice(0,-3);} if(v) parts.unshift(v); this.value=parts.join('.');",
                           ])
                           ->rule('numeric') // Valida que solo haya números
                           ->validationMessages([
                               'numeric' => 'Debe ser un número válido.',
                           ]),
                           
                    
                      ])
                      ->columns(3)
                      ->disableItemCreation() // 👈 Opcional: Bloquear nuevos elementos
                      ->disableItemDeletion() ,// 👈 Opcional: Bloquear eliminación
                              ]),

                              // Sección para dispositivos comprados (relación)
               Forms\Components\Section::make('Referencias Personales')
               ->schema([
                   Repeater::make('referenciasPersonales1') // 👈 Nombre de la relación hasMany
                       ->relationship()
                       ->schema([
                        Forms\Components\TextInput::make('Primer_Nombre_rf1')
                        ->required()
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        Forms\Components\TextInput::make('Segundo_Nombre_rf1')
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        Forms\Components\TextInput::make('Primer_Apellido_rf1')
                        ->required()
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        Forms\Components\TextInput::make('Segundo_Apellido_rf1')
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        Forms\Components\TextInput::make('Celular_rf1')
                        ->maxLength(14) // Hasta 10 dígitos + espacios
                        ->extraInputAttributes([
                            // Mientras escribe, limita a 10 dígitos sin espacios
                            'oninput' => "this.value = this.value.replace(/\\D/g, '').slice(0,10);",
                            // Al perder foco, formatea con espacios: 123 456 7890
                            'onblur' => "let d=this.value.replace(/\\D/g,'').slice(0,10); let f=''; if(d.length>0) f=d.substr(0,3); if(d.length>3) f+=' '+d.substr(3,3); if(d.length>6) f+=' '+d.substr(6); this.value=f;",
                        ])
                        ->rule('regex:/^[\d ]{0,14}$/') // Solo dígitos y espacios
                        ->validationMessages([
                            'regex' => 'Solo se permiten números y espacios.',
                            'max_length' => 'Máximo 10 dígitos permitidos.',
                        ]),

                        Select::make('Parentesco_rf1')
                        ->label('parentesco')
                        ->required()
                        ->options(
                            // Obtener todas las marcas de z_marca
                            ZParentescoPersonal::all()->pluck('parentesco', 'idparentesco')
                        ),
                        Select::make('idtiempo_conocerlonum')
                        ->label('Tiempo de Conocerlo')
                        ->required()
                        ->options(
                            // Obtener todas las marcas de z_marca
                            ZTiempoConocerloNum::all()->pluck('numeros', 'idtiempo_conocerlonum')
                        ),
                        Select::make('idtiempoconocerlo')
                        ->label('Tiempo de Conocerlo')
                        ->required()
                        ->options(
                            // Obtener todas las marcas de z_marca
                            ZTiempoConocerlo::all()->pluck('tiempo', 'idtiempoconocerlo')
                        )

                       ])
                       ->columns(3)
                       ->disableItemCreation() // 👈 Opcional: Bloquear nuevos elementos
                       ->disableItemDeletion() ,// 👈 Opcional: Bloquear eliminación

                       Repeater::make('referenciasPersonales2') // 👈 Nombre de la relación hasMany
                       ->relationship()
                       ->schema([
                        Forms\Components\TextInput::make('Primer_Nombre_rf2')
                        ->required()
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        Forms\Components\TextInput::make('Segundo_Nombre_rf2')
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        Forms\Components\TextInput::make('Primer_Apellido_rf2')
                        ->required()
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        Forms\Components\TextInput::make('Segundo_Apellido_rf2')
                        ->extraInputAttributes([
                            'oninput' => "this.value = this.value.replace(/[^A-Za-z]/g, '').toUpperCase();",
                            'onblur'  => "this.value = this.value.toUpperCase();",
                        ])
                        ->rule('alpha') // Solo letras
                        ->validationMessages([
                            'alpha' => 'Solo se permiten letras en el nombre.',
                        ]),
                        Forms\Components\TextInput::make('Celular_rf2')
                        ->maxLength(14) // Hasta 10 dígitos + espacios
                        ->extraInputAttributes([
                            // Mientras escribe, limita a 10 dígitos sin espacios
                            'oninput' => "this.value = this.value.replace(/\\D/g, '').slice(0,10);",
                            // Al perder foco, formatea con espacios: 123 456 7890
                            'onblur' => "let d=this.value.replace(/\\D/g,'').slice(0,10); let f=''; if(d.length>0) f=d.substr(0,3); if(d.length>3) f+=' '+d.substr(3,3); if(d.length>6) f+=' '+d.substr(6); this.value=f;",
                        ])
                        ->rule('regex:/^[\d ]{0,14}$/') // Solo dígitos y espacios
                        ->validationMessages([
                            'regex' => 'Solo se permiten números y espacios.',
                            'max_length' => 'Máximo 10 dígitos permitidos.',
                        ]),

                        Select::make('Parentesco_rf2')
                        ->label('parentesco')
                        ->required()
                        ->options(
                            // Obtener todas las marcas de z_marca
                            ZParentescoPersonal::all()->pluck('parentesco', 'idparentesco')
                        ),
                        Select::make('idtiempo_conocerlonum')
                        ->label('Tiempo de Conocerlo')
                        ->required()
                        ->options(
                            // Obtener todas las marcas de z_marca
                            ZTiempoConocerloNum::all()->pluck('numeros', 'idtiempo_conocerlonum')
                        ),
                        Select::make('idtiempoconocerlo')
                        ->label('Tiempo de Conocerlo')
                        ->required()
                        ->options(
                            // Obtener todas las marcas de z_marca
                            ZTiempoConocerlo::all()->pluck('tiempo', 'idtiempoconocerlo')
                        )

                       ])
                       ->columns(3)
                       ->disableItemCreation() // 👈 Opcional: Bloquear nuevos elementos
                       ->disableItemDeletion() ,// 👈 Opcional: Bloquear eliminación
     ]),


       // Sección para dispositivos comprados (relación)
       Forms\Components\Section::make('Detalles cliente')
       ->schema([
           Repeater::make('detallesCliente') // 👈 Nombre de la relación hasMany
               ->relationship()
               ->schema([

                   Select::make('idplataforma')
                       ->label('Plataforma')
                       ->required()
                       ->options(
                           // Obtener todas las marcas de z_marca
                           ZPlataformaCredito::all()->pluck('plataforma', 'idplataforma')
                       )
                       ->searchable()
                       ->preload(),

                       Select::make('idcomision')
                       ->label('Comisión')
                       ->required()
                       ->options(
                           // Obtener todas las marcas de z_marca
                           ZComision::all()->pluck('comision', 'id')
                       )
                       ->searchable()
                       ->preload(),

                       Select::make('codigo_asesor')
                       ->label('Código Asesor')
                       ->options(
                           InfTrab::pluck('Codigo_vendedor', 'Codigo_vendedor')
                       )
                       ->searchable()
                       ->reactive()
                       ->required()
                       ->default(function ($record) {
                           return $record?->codigo_asesor; // Carga el valor almacenado
                       })
                       ->afterStateHydrated(function ($state, callable $set, $record) {
                           // Carga inicial de datos si hay un código almacenado
                           if ($state && $record) {
                               $infTrab = InfTrab::where('Codigo_vendedor', $state)
                                   ->with('aaPrin.asesor', 'aaPrin.sede') // Carga eager
                                   ->first();
           
                               if ($infTrab && $infTrab->aaPrin) {
                                   $set('ID_Asesor', $infTrab->aaPrin->ID_Asesor);
                                   $set('idsede', $infTrab->aaPrin->ID_Sede);
                                   $set('nombre_asesor', $infTrab->aaPrin->asesor->Nombre ?? '');
                                   $set('nombre_sede', $infTrab->aaPrin->sede->Name_Sede ?? '');
                               }
                           }
                       })
                       ->afterStateUpdated(function ($state, callable $set) {
                           // Actualiza campos al cambiar el código
                           $infTrab = InfTrab::where('Codigo_vendedor', $state)
                               ->with('aaPrin.asesor', 'aaPrin.sede')
                               ->first();
           
                           if ($infTrab && $infTrab->aaPrin) {
                               $set('ID_Asesor', $infTrab->aaPrin->ID_Asesor);
                               $set('idsede', $infTrab->aaPrin->ID_Sede);
                               $set('nombre_asesor', $infTrab->aaPrin->asesor->Nombre ?? 'N/A');
                               $set('nombre_sede', $infTrab->aaPrin->sede->Name_Sede ?? 'N/A');
                           } else {
                               // Limpiar campos si no hay datos
                               $set('ID_Asesor', null);
                               $set('idsede', null);
                               $set('nombre_asesor', '');
                               $set('nombre_sede', '');
                           }
                       }),
           
                   // Campos ocultos para guardar IDs
                   Forms\Components\TextInput::make('ID_Asesor')
                       ->hidden()
                       ->dehydrated(), // Asegura que se guarde en la BD
           
                       Forms\Components\TextInput::make('idsede')
                       ->hidden()
                       ->dehydrated(),
           
                   // Campos de solo lectura para mostrar datos
                   Forms\Components\TextInput::make('nombre_asesor')
                       ->label('Nombre Asesor')
                       ->disabled()
                       ->dehydrated(false), // No se guarda en la BD
           
                       Forms\Components\TextInput::make('nombre_sede')
                       ->label('Sede')
                       ->disabled()
                       ->dehydrated(false),

                       Select::make('ID_PDV_agente')
                       ->label('Punto de venta agente')
                       ->required()
                       ->options(
                           // Obtener todas las marcas de z_marca
                           ZPdvAgenteDistritec::all()->pluck('PDV_agente', 'ID_PDV_agente')
                       )
                       ->searchable()
                       ->preload(),
               ])
               ->columns(3)
               ->disableItemCreation() // 👈 Opcional: Bloquear nuevos elementos
               ->disableItemDeletion() ,// 👈 Opcional: Bloquear eliminación
                       ]),                     
     ]);                 
}
    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id_cliente')
                    ->sortable()
                    ->searchable(),

                  // Nueva columna para Nombre Auxiliar
                Tables\Columns\TextColumn::make('gestion.gestorDistritec.Nombre_gestor')
                  ->label('Nombre Auxiliar')
                  ->searchable()
                  ->sortable()
                  ->toggleable(),
                
                
                Tables\Columns\TextColumn::make('fecha_registro')
                    ->date('d/m/Y')
                    ->sortable(),
                
                Tables\Columns\TextColumn::make('hora')
                    ->time('H:i')
                    ->sortable(),

                Tables\Columns\TextColumn::make('cedula')
                    ->searchable(),
                
                Tables\Columns\TextColumn::make('token.token')
                    ->label('Token')
                    ->searchable(
                        query: function (Builder $query, string $search) {
                            $query->whereHas('token', function ($q) use ($search) {
                                $q->where('token', 'like', "%{$search}%");
                            });
                        }
                    ),
                
                // Nueva columna para Estado
                Tables\Columns\BadgeColumn::make('gestion.estadoCredito.Estado_Credito')
                    ->label('Estado Crédito')
                    ->colors([
                        'success' => 'APROBADO',
                        'warning' => 'PENDIENTE',
                        'danger' => 'NO APROBADO'
                    ])
                    ->searchable()
                    ->sortable()
                    ->toggleable()

                      
               
            ->sortable()
            ->toggleable()
            ->copyable() // Opcional: permite copiar el token
            ->limit(10), // Muestra solo los primeros 10 caracteres

            Tables\Columns\BadgeColumn::make('gestion.comentarios')
                    ->label('Comentarios')
                    ->searchable()
                    ->sortable()
                    ->toggleable()
   
            ])
            ->filters([
                Tables\Filters\Filter::make('fecha_registro')
                    ->form([Forms\Components\DatePicker::make('fecha')])
                    ->query(function ($query, array $data) {
                        if ($data['fecha']) {
                            $query->whereDate('fecha_registro', $data['fecha']);
                        }
                    }),

                    Tables\Filters\Filter::make('token')
                    ->form([Forms\Components\TextInput::make('token')])
                    ->query(fn ($query, $data) => 
                        $query->when($data['token'], fn ($q) => 
                            $q->whereHas('token', fn ($q) => 
                                $q->where('token', 'like', "%{$data['token']}%")
                            )
                        )
                ),
                
                
                // Nuevos filtros
                Tables\Filters\SelectFilter::make('gestor')
                    ->relationship('gestion.gestorDistritec', 'Nombre_gestor')
                    ->searchable()
                    ->preload(),
                
                Tables\Filters\SelectFilter::make('estado')
                    ->relationship('gestion.estadoCredito', 'Estado_Credito')
                    ->searchable()
                    ->preload()
            ])
            ->actions([
                Tables\Actions\EditAction::make(),
                Tables\Actions\DeleteAction::make(),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
                
            ]);
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
        ->with(['token', 'gestion.gestorDistritec', 'gestion.estadoCredito',
         'clientesNombreCompleto', 'ClientesContacto']);
    }

    

    public static function getPages(): array
    {
        return [
            'index' => Pages\ListClientes::route('/'),
            'create' => Pages\CreateCliente::route('/create'),
            'edit' => Pages\EditCliente::route('/{record}/edit'),
        ];
    }
}