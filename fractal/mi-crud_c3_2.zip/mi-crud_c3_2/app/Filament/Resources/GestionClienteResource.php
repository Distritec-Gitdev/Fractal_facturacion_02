<?php

namespace App\Filament\Resources;

use App\Filament\Resources\GestionClienteResource\Pages;
use App\Filament\Resources\GestionClienteResource\RelationManagers;
use App\Models\GestionCliente;
use Filament\Forms;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\SoftDeletingScope;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Checkbox;
use Filament\Forms\Components\Wizard;
use Filament\Forms\Components\Wizard\Step;
use App\Models\ReferenciaPersonal1; // ✅ Agrega esta línea
use App\Models\ZParentescoPersonal;
use App\Models\ZDepartamentos;
use App\Models\ZMunicipios;
use App\Models\ZTiempoConocerloNum;
use App\Models\ZTiempoConocerlo;
use Filament\Forms\Components\Repeater;
use App\Models\ZMarca;
use App\Models\ZModelo;
use App\Models\ZGarantia;
use App\Models\ZPago;
use App\Models\ZPlataformaCredito;
use App\Models\ZComision;
use App\Models\InfTrab;
use App\Models\ZPdvAgenteDistritec;
use App\Models\ClientesContacto;
use Filament\Forms\Components\Grid;






use function Laravel\Prompts\select;

class GestionClienteResource extends Resource
{
    protected static ?string $model = \App\Models\Cliente::class;
  
    protected static ?string $label = 'Gestión de Cliente';
    protected static ?string $navigationIcon = 'heroicon-o-rectangle-stack';


        public static function form(Form $form): Form
    {
        return $form
            
            ->schema([
                Wizard::make([
                    Step::make('Datos del Cliente')
                        ->schema([
                            TextInput::make('cedula')
                        ->extraAttributes(['class' => 'text-lg font-bold'])
                        ->label('Cédula')
                        ->required()
                        ->numeric() // ✅ Solo números
                        ->maxLength(10) // ✅ Máximo 10 dígitos
                        ->mask('9999999999') // 🎯 Máscara opcional
                        ->validationMessages([
                            'max_length' => 'Máximo 10 dígitos permitidos.',
                        ]),
                        Grid::make(2)->schema([
                            Select::make('id_departamento')
                            ->label('Departamento Expedicion Documento') 
                            ->required()
                            ->options(ZDepartamentos::all()->pluck('name_departamento', 'id'))
                            ->searchable()
                            ->preload(),
                        Select::make('id_municipio')
                            ->label('Municipio Expedicion Documento') 
                            ->required()
                            ->options(ZMunicipios::all()->pluck('name_municipio', 'id'))
                            ->searchable()
                            ->preload(),
                        ]),
                            DatePicker::make('fecha_nac')->label('Fecha de Nacimiento')->format('Y-m-d')->displayFormat('d/m/Y')->required(),
                        
                        Section::make('Nombre Completo')
                        ->schema([
                                Repeater::make('clientesNombreCompleto') // 👈 Nombre de la relación hasMany
                                ->relationship()
                                ->schema([
                                    Grid::make(2)->schema([
                                        TextInput::make('Primer_nombre_cliente')->label('Primer Nombre')->required(),
                                        TextInput::make('Segundo_nombre_cliente')->label('Segundo Nombre'),
                                    ]),
                                    Grid::make(2)->schema([
                                        TextInput::make('Primer_apellido_cliente')->label('Primer Apellido')->required(),
                                        TextInput::make('Segundo_apellido_cliente')->label('Segundo Apellido'),
                                    ]),
                                ]),
                                
                        ]),

                    
                        Forms\Components\Section::make('Datos Personales')
                        ->schema([
                            Repeater::make('clientesContacto') // 👈 Nombre de la relación hasMany
                            ->relationship()
                            ->disableItemCreation() // 🚫 Quita el botón "Añadir"
                            ->disableItemDeletion()
                            ->schema([
                            Grid::make(2)->schema([
                                
                                DatePicker::make('fecha_expedicion')->label('Fecha de expedición')->hint('En que fecha saco la cedula?')->hintColor('info') ->hintIcon('phosphor-push-pin-bold'),
                                TextInput::make('correo')
                                ->label('Correo')
                                ->required()
                                ->email()
                                ->maxLength(100)
                                ->hint('Utilice un correo verdadero')
                                ->regex('/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/') // ✅ Formato estricto
                                ->validationMessages([
                                    'email' => 'Formato de correo inválido.',
                                    'max' => 'Máximo 100 caracteres.',
                                    'regex' => 'Caracteres no permitidos.',
                                ]),
                            ]),
                            Grid::make(2)->schema([
                                TextInput::make('tel')
                                ->label('Teléfono')
                                ->required()
                                ->numeric() // ✅ Solo números
                                ->maxLength(10) // ✅ Máximo 10 dígitos
                                ->mask('9999999999') // 🎯 Máscara opcional
                                ->validationMessages([
                                    'max_length' => 'Máximo 10 dígitos permitidos.',
                                ]),
                                TextInput::make('tel_alternativo')->label('Teléfono Alterno')
                                ->numeric() // ✅ Solo números
                                ->maxLength(10) // ✅ Máximo 10 dígitos
                                ->mask('9999999999') // 🎯 Máscara opcional
                                ->validationMessages([
                                    'max_length' => 'Máximo 10 dígitos permitidos.',
                                ]),
                            ]),
                            Grid::make(2)->schema([
                                Select::make('residencia_id_departamento')
                                    ->label('Departamento Residencia') 
                                    ->required()
                                    ->options(ZDepartamentos::all()->pluck('name_departamento', 'id'))
                                    ->searchable()
                                    ->preload()
                                    ->distinct()
                                    ->required(),
    
                                Select::make('residencia_id_municipio')
                                    ->label('Municipio Residencia') 
                                    ->required()
                                    ->options(ZMunicipios::all()->pluck('name_municipio', 'id'))
                                    ->searchable()
                                    ->preload()
                                    ->distinct()
                                    ->required(),
                            ]),
                            Grid::make(2)->schema([
                                TextInput::make('direccion')->label('Dirección')->required(),
                                TextInput::make('empresa')->label('Empresa en la que labora'),
                            ]),
                            Grid::make(2)->schema([
                                TextInput::make('telefono_empresa')
                                ->label('Teléfono de Empresa')
                                ->numeric() // ✅ Solo números
                                ->maxLength(10) // ✅ Máximo 10 dígitos
                                ->mask('9999999999') // 🎯 Máscara opcional
                                ->validationMessages([
                                    'max_length' => 'Máximo 10 dígitos permitidos.',
                                ]),
                                
                            ]),
                                Checkbox::make('Independiente')->label('¿Es independiente?'),
                            ]),

                        ]),
                    
                    ]),

                        Step::make('Referencia 1')
                        ->schema([
                            Repeater::make('referenciasPersonales1') // 👈 Nombre de la relación hasMany
                            ->relationship()
                            ->schema([
                             Forms\Components\TextInput::make('Primer_Nombre_rf1'),
                             Forms\Components\TextInput::make('Segundo_Nombre_rf1'),
                             Forms\Components\TextInput::make('Primer_Apellido_rf1'),
                             Forms\Components\TextInput::make('Segundo_Apellido_rf1'),
                             Forms\Components\TextInput::make('Celular_rf1')
                            ->required()
                            ->numeric() // ✅ Solo números
                            ->maxLength(10) // ✅ Máximo 10 dígitos
                            ->mask('9999999999') // 🎯 Máscara opcional
                            ->validationMessages([
                                'max_length' => 'Máximo 10 dígitos permitidos.',
                            ]),
                             Select::make('Parentesco_rf1')
                             ->label('parentesco')
                             ->required()
                             ->options(
                                 // Obtener todas las marcas de z_marca
                                 ZParentescoPersonal::all()->pluck('parentesco', 'idparentesco')
                             ),
                             Select::make('idtiempo_conocerlonum')
                             ->label('Tiempo de Conocerlo')
                             ->required()
                             ->options(
                                 // Obtener todas las marcas de z_marca
                                 ZTiempoConocerloNum::all()->pluck('numeros', 'idtiempo_conocerlonum')
                             ),
                             Select::make('idtiempoconocerlo')
                             ->label('Tiempo de Conocerlo')
                             ->required()
                             ->options(
                                 // Obtener todas las marcas de z_marca
                                 ZTiempoConocerlo::all()->pluck('tiempo', 'idtiempoconocerlo')
                             )
     
                            ])
                        ]),

                        Step::make('Referencia 2')
                        ->schema([
                            Repeater::make('referenciasPersonales2') // 👈 Nombre de la relación hasMany
                       ->relationship()
                       ->schema([
                        Forms\Components\TextInput::make('Primer_Nombre_rf2'),
                        Forms\Components\TextInput::make('Segundo_Nombre_rf2'),
                        Forms\Components\TextInput::make('Primer_Apellido_rf2'),
                        Forms\Components\TextInput::make('Segundo_Apellido_rf2'),
                        Forms\Components\TextInput::make('Celular_rf2')
                        ->required()
                        ->numeric() // ✅ Solo números
                        ->maxLength(10) // ✅ Máximo 10 dígitos
                        ->mask('9999999999') // 🎯 Máscara opcional
                        ->validationMessages([
                            'max_length' => 'Máximo 10 dígitos permitidos.',
                        ]),
                        Select::make('Parentesco_rf2')
                        ->label('parentesco')
                        ->required()
                        ->options(
                            // Obtener todas las marcas de z_marca
                            ZParentescoPersonal::all()->pluck('parentesco', 'idparentesco')
                        ),
                        Select::make('idtiempo_conocerlonum')
                        ->label('Tiempo de Conocerlo')
                        ->required()
                        ->options(
                            // Obtener todas las marcas de z_marca
                            ZTiempoConocerloNum::all()->pluck('numeros', 'idtiempo_conocerlonum')
                        ),
                        Select::make('idtiempoconocerlo')
                        ->label('Tiempo de Conocerlo')
                        ->required()
                        ->options(
                            // Obtener todas las marcas de z_marca
                            ZTiempoConocerlo::all()->pluck('tiempo', 'idtiempoconocerlo')
                        )
     
                            ])
                        ]),

                        Step::make('Datos del Equipo')
                        ->schema([
                            Repeater::make('dispositivosComprados') // 👈 Nombre de la relación hasMany
                            ->relationship()
                            ->schema([
                                Select::make('id_marca')
                                    ->label('Marca del Dispositivo')
                                    ->required()
                                    ->options(
                                        // Obtener todas las marcas de z_marca
                                        ZMarca::all()->pluck('name_marca', 'idmarca')
                                    )
                                    ->searchable()
                                    ->preload(),
     
                                Select::make('idmodelo')
                                    ->label('Modelo del Dispositivo')
                                    ->required()
                                    ->options(
                                        // Obtener todos los modelos
                                        ZModelo::all()->pluck('name_modelo', 'idmodelo')
                                    )
                                    ->searchable()
                                    ->preload(),
     
                                Select::make('idgarantia')
                                    ->label('Garantía')
                                    ->required()
                                    ->options(
                                        // Obtener todos los modelos
                                        ZGarantia::all()->pluck('garantia', 'idgarantia')
                                    )
                                    ->searchable()
                                    ->preload(),
                                 Forms\Components\TextInput::make('imei')
                                 ->required()
                                 ->numeric() // ✅ Solo números
                                 ->maxLength(15) // ✅ Máximo 10 dígitos
                                 ->mask('9999999999') // 🎯 Máscara opcional
                                 ->validationMessages([
                                     'max_length' => 'Máximo 15 dígitos permitidos.',
                                 ]),
                                 
                          
                                    ]),

                            Repeater::make('dispositivosPago') // 👈 Nombre de la relación hasMany
                      ->relationship()
                      ->schema([

                         DatePicker::make('fecha_pc')
                            ->label('Fecha Primer Cuota')
                            ->required()
                            ->displayFormat('d/m/Y') // Formato de visualización (opcional)
                            ->native(false)
                            ->format('Y-m-d'),
                         
                          Select::make('idpago')
                              ->label('Periodo de Pago')
                              ->required()
                              ->options(
                                  // Obtener todas las marcas de z_marca
                                  ZPago::all()->pluck('periodo_pago', 'idpago')
                              )
                              ->searchable()
                              ->preload(),

                           
                           Forms\Components\TextInput::make('cuota_inicial')->prefix('$')->numeric()->required(),
                           Forms\Components\TextInput::make('num_cuotas')->numeric(),
                           Forms\Components\TextInput::make('valor_cuotas')->prefix('$')->numeric()->required(),
                           
                    
                      ])
                        ]),



                        Step::make('Detalles Cliente')
                        ->schema([
                            Repeater::make('detallesCliente') // 👈 Nombre de la relación hasMany
                        ->relationship()
                        ->schema([

                   Select::make('idplataforma')
                       ->label('Plataforma')
                       ->required()
                       ->options(
                           // Obtener todas las marcas de z_marca
                           ZPlataformaCredito::all()->pluck('plataforma', 'idplataforma')
                       )
                       ->searchable()
                       ->preload(),

                       Select::make('idcomision')
                       ->label('Comisión')
                       ->required()
                       ->options(
                           // Obtener todas las marcas de z_marca
                           ZComision::all()->pluck('comision', 'id')
                       )
                       ->searchable()
                       ->preload(),

                       Select::make('codigo_asesor')
                       ->label('Código Asesor')
                       ->options(
                           InfTrab::pluck('Codigo_vendedor', 'Codigo_vendedor')
                       )
                       ->searchable()
                       ->reactive()
                       ->required()
                       ->default(function ($record) {
                           return $record?->codigo_asesor; // Carga el valor almacenado
                       })
                       ->afterStateHydrated(function ($state, callable $set, $record) {
                           // Carga inicial de datos si hay un código almacenado
                           if ($state && $record) {
                               $infTrab = InfTrab::where('Codigo_vendedor', $state)
                                   ->with('aaPrin.asesor', 'aaPrin.sede') // Carga eager
                                   ->first();
           
                               if ($infTrab && $infTrab->aaPrin) {
                                   $set('ID_Asesor', $infTrab->aaPrin->ID_Asesor);
                                   $set('idsede', $infTrab->aaPrin->ID_Sede);
                                   $set('nombre_asesor', $infTrab->aaPrin->asesor->Nombre ?? '');
                                   $set('nombre_sede', $infTrab->aaPrin->sede->Name_Sede ?? '');
                               }
                           }
                       })
                       ->afterStateUpdated(function ($state, callable $set) {
                           // Actualiza campos al cambiar el código
                           $infTrab = InfTrab::where('Codigo_vendedor', $state)
                               ->with('aaPrin.asesor', 'aaPrin.sede')
                               ->first();
           
                           if ($infTrab && $infTrab->aaPrin) {
                               $set('ID_Asesor', $infTrab->aaPrin->ID_Asesor);
                               $set('idsede', $infTrab->aaPrin->ID_Sede);
                               $set('nombre_asesor', $infTrab->aaPrin->asesor->Nombre ?? 'N/A');
                               $set('nombre_sede', $infTrab->aaPrin->sede->Name_Sede ?? 'N/A');
                           } else {
                               // Limpiar campos si no hay datos
                               $set('ID_Asesor', null);
                               $set('idsede', null);
                               $set('nombre_asesor', '');
                               $set('nombre_sede', '');
                           }
                       }),
           
                   // Campos ocultos para guardar IDs
                   Forms\Components\TextInput::make('ID_Asesor')
                       ->hidden()
                       ->dehydrated(), // Asegura que se guarde en la BD
           
                       Forms\Components\TextInput::make('idsede')
                       ->hidden()
                       ->dehydrated(),
           
                   // Campos de solo lectura para mostrar datos
                   Forms\Components\TextInput::make('nombre_asesor')
                       ->label('Nombre Asesor')
                       ->disabled()
                       ->dehydrated(false), // No se guarda en la BD
           
                       Forms\Components\TextInput::make('nombre_sede')
                       ->label('Sede')
                       ->disabled()
                       ->dehydrated(false),

                       Select::make('ID_PDV_agente')
                       ->label('Punto de venta agente')
                       ->required()
                       ->options(
                           // Obtener todas las marcas de z_marca
                           ZPdvAgenteDistritec::all()->pluck('PDV_agente', 'ID_PDV_agente')
                       )
                       ->searchable()
                       ->preload(),
               ])
                        ]),

                ])
                ->columnSpanFull()
                
            ]);
            
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('id_cliente')
                    ->label('ID Cliente')
                    ->sortable(),
    
                Tables\Columns\TextColumn::make('gestorAuxiliar.Nombre_gestor')
                    ->label('Nombre Auxiliar')
                    ->sortable()
                    ->searchable(),
    
                Tables\Columns\TextColumn::make('fecha_registro')
                    ->label('Fecha Registro')
                    ->date(),
    
                Tables\Columns\TextColumn::make('hora')
                    ->label('Hora'),
    
                Tables\Columns\TextColumn::make('cedula')
                    ->label('Cédula'),
    
                Tables\Columns\BadgeColumn::make('persona.estado')
                    ->label('Estado Crédito')
                    ->colors([
                        'success' => 'aprobado',
                        'danger' => 'no aprobado',
                    ])
                    ->formatStateUsing(fn (string $state) => strtoupper($state)),
    
                Tables\Columns\TextColumn::make('persona.comentarios')
                    ->label('Comentarios'),
            ])
            ->searchPlaceholder('Buscar por cédula o nombre')
            ->actions([
                Tables\Actions\EditAction::make(),
            ])
            ->headerActions([
                Tables\Actions\CreateAction::make()->label('Nuevo Cliente'),
            ])
            ->bulkActions([
                Tables\Actions\BulkActionGroup::make([
                    Tables\Actions\DeleteBulkAction::make(),
                ]),
            ]);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index'  => Pages\ListGestionClientes::route('/'),
            'create' => Pages\CreateGestionCliente::route('/create'),
            'edit'   => Pages\EditGestionCliente::route('/{record}/edit'),
        ];
    }




}
