<?php

namespace App\Filament\Resources\GestionClienteResource\Pages;

use App\Filament\Resources\GestionClienteResource;
use Filament\Actions;
use Filament\Resources\Pages\EditRecord;

class EditGestionCliente extends EditRecord
{
    protected static string $resource = GestionClienteResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\DeleteAction::make(),
        ];
    }
}
