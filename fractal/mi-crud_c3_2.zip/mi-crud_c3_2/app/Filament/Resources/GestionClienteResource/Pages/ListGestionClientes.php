<?php

namespace App\Filament\Resources\GestionClienteResource\Pages;

use App\Filament\Resources\GestionClienteResource;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;

class ListGestionClientes extends ListRecords
{
    protected static string $resource = GestionClienteResource::class;

    protected function getHeaderActions(): array
    {
        return [
            Actions\CreateAction::make(),
        ];
    }
}
