<?php

// app/Models/Cliente.php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Events\ClienteUpdated; // 👈 Asegúrate de importar el evento
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne; // Asegúrate de importar esto


class Cliente extends Model
{
    protected $table = 'clientes'; // Nombre de la tabla
    protected $primaryKey = 'id_cliente'; // Clave primaria personalizada
    public $incrementing = true; // Si el ID no es autoincremental
    public $timestamps = true; 

    

    protected $fillable = [
        'id_cliente',
        'cedula',
        'fecha_registro',
        'hora',
        'fecha_nac',
        'ID_Cliente_Nombre',
        'ID_Cliente_Contacto',
        'id_departamento',
        'id_municipio',
        
    ];

    protected $casts = [
        'fecha_registro' => 'date',
        'hora' => 'datetime:H:i:s' // Formato de hora
    ];
        // App\Models\Cliente.php
    protected $rules = [
        'cedula' => 'required|numeric|max:10',
        'correo' => 'required|email|max:100|regex:/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/',
    ];
    

    public function gestion()
{
    return $this->hasOne(Gestion::class, 'id_cliente', 'id_cliente');
}

// app/Models/Cliente.php
public function token()
{
    return $this->hasOne(Token::class, 'id_cliente', 'id_cliente');
}
// app/Models/Cliente.php
public function clientesNombreCompleto(): HasOne
{
    return $this->hasOne(ClientesNombreCompleto::class, 'id_cliente', 'id_cliente');
}


public function clientesContacto(): HasOne
    {
        return $this->hasOne(ClientesContacto::class, 'id_cliente', 'id_cliente');
    }


public function dispositivosComprados()
{
    return $this->hasMany(DispositivosComprados::class, 'id_cliente', 'id_cliente');
}

public function dispositivosPago()
{
    return $this->hasMany(DispositivosPago::class, 'id_cliente', 'id_cliente');
}

public function referenciasPersonales1()
{
    return $this->hasMany(
        ReferenciaPersonal1::class,
        'ID_Cliente', 
        'id_cliente'
      
    );
}

public function referenciasPersonales2()
{
    return $this->hasMany(
        ReferenciaPersonal2::class,
        'ID_Cliente', 
        'id_cliente'
      
    );
}

public function detallesCliente()
{
    return $this->hasMany(
        DetallesCliente::class,
        'id_cliente', 
        'id_cliente'
      
    );
}

public function departamento()
{
    return $this->belongsTo(ZDepartamentos::class, 'id', 'id_departamento');
}

public function municipios()
{
    return $this->belongsTo(ZMunicipios::class, 'id', 'id_municipio');
}


protected static function booted()
{
    // Se ejecuta después de cualquier actualización del modelo
    static::updated(function ($cliente) {
        event(new ClienteUpdated($cliente));
    });
}

}