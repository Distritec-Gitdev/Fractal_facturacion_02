<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ClientesContacto extends Model
{
    protected $table = 'clientes_contacto';
    protected $primaryKey = 'id_contacto';
    
    protected $fillable = [
        'id_cliente',
        'correo',
        'tel',
        'tel_alternativo',
        'direccion',
        'residencia_id_departamento',
        'residencia_id_municipio',
    ];

    public function cliente()
    {
        return $this->belongsTo(Cliente::class, 'id_cliente', 'id_cliente');
    }

    public function departamento()
    {
        return $this->belongsTo(ZDepartamentos::class, 'id', 'residencia_id_departamento');
    }

    public function municipios()
    {
        return $this->belongsTo(ZMunicipios::class, 'id', 'residencia_id_municipio');
    }
}