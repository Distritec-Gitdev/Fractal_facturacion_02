<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DetallesCliente extends Model
{
    protected $table = 'detalles_cliente'; // Nombre de la tabla en la BD
    protected $primaryKey = 'ID_Detalles_cliente'; // Clave primaria personalizada
    
    
    public $timestamps = true; 
    
    protected $fillable = [
        'id_cliente',
        'idplataforma',
        'ID_Asesor',
        'idsede',
        'idcomision',
        'codigo_asesor',
        'ID_PDV_agente'
    ];


    public function plataformaCredito(): BelongsTo
    {
        return $this->belongsTo(
            ZPlataformaCredito::class,
            'idplataforma', // Columna en tabla gestion
            'idplataforma'  // Columna en tabla z_gestores_distritec
        );
    }

    public function comision(): BelongsTo
    {
        return $this->belongsTo(
            ZComision::class,
            'id', // Columna en tabla gestion
            'idcomision'  // Columna en tabla z_gestores_distritec
        );
    }


     // Relación con Asesor (desde BD externa)
     public function asesorExterno()
     {
         return $this->belongsTo(Asesor::class, 'ID_Asesor', 'ID_Asesor')
             ->setConnection('inf_asesores'); // Usar conexión externa
     }
 
     // Relación con Sede (desde BD externa)
     public function sedeExterna()
     {
         return $this->belongsTo(Sede::class, 'idsede', 'ID_Sede')
             ->setConnection('inf_asesores');
     }


     public function agenteDistritec(): BelongsTo
     {
         return $this->belongsTo(
            ZPdvAgenteDistritec::class,
             'ID_PDV_agente', 
             'ID_PDV_agente'  
         );
     }
}
