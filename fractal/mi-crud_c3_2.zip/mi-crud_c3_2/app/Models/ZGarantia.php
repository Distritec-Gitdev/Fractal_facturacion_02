<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ZGarantia extends Model
{
    protected $table = 'z_garantia';
    protected $primaryKey = 'idgarantia';

    protected $fillable = ['garantia'];
}
