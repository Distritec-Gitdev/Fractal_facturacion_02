<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ZModelo extends Model
{
    
    protected $table = 'z_modelo';
    protected $primaryKey = 'idmodelo';
    
    protected $fillable = [
        'name_modelo'
       
    ];
}
