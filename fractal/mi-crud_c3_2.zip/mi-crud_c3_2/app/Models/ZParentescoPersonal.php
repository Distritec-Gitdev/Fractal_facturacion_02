<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ZParentescoPersonal extends Model
{
    protected $table = 'z_parentesco_personal'; // Nombre de la tabla en la BD
    protected $primaryKey = 'idparentesco'; // Clave primaria personalizada
    
    protected $fillable = [
        'parentesco' 
    ];


      // Relación inversa con ReferenciaPersonal1 (hasMany)
      public function referenciasPersonales1()
      {
          return $this->hasMany(
              ReferenciaPersonal1::class,
              'Parentesco_rf1',  // FK en referencia_personal1
              'idparentesco'     // PK en z_parentesco_personal
          );
      }

}
