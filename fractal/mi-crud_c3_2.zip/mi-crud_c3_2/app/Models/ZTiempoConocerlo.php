<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ZTiempoConocerlo extends Model
{
    protected $table = 'z_tiempo_conocerlo'; // Nombre de la tabla en la BD
    protected $primaryKey = 'idtiempoconocerlo'; // Clave primaria personalizada
    
    protected $fillable = [
        'tiempo' 
    ];
}
