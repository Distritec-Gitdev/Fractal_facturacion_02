<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ZTiempoConocerloNum extends Model
{
    protected $table = 'z_tiempo_conocerlo_num'; // Nombre de la tabla en la BD
    protected $primaryKey = 'idtiempo_conocerlonum'; // Clave primaria personalizada
    
    protected $fillable = [
        'numeros' 
    ];
}
