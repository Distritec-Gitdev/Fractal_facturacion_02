import './bootstrap';
import Echo from 'laravel-echo';
import Pusher from 'pusher-js';

// Configura Pusher como variable global
window.Pusher = Pusher;

// 👇 Añade esto para verificar las variables
console.log('Clave Pusher:', import.meta.env.VITE_PUSHER_APP_KEY);

// Inicializa Echo con la configuración correcta
window.Echo = new Echo({
    broadcaster: 'pusher',
    key: import.meta.env.VITE_PUSHER_APP_KEY, // Debe ser "local"
    wsHost: import.meta.env.VITE_PUSHER_HOST, // "127.0.0.1"
    wsPort: import.meta.env.VITE_PUSHER_PORT, // 6001
    cluster: import.meta.env.VITE_PUSHER_APP_CLUSTER, // "mt1"
    forceTLS: false,
    enabledTransports: ['ws', 'wss'],
    disableStats: true,
});

// Escucha el canal (opcional, solo para prueba)
window.Echo.channel('person')
    .listen('.PersonUpdated', (e) => {
        console.log('Evento recibido:', e);
        Livewire.dispatch('refresh'); // 👈 Actualiza todos los componentes Livewire
    });


// 👇 Añadir canal de Cliente
window.Echo.channel('cliente')
.listen('.ClienteUpdated', (e) => {
    console.log('Evento Cliente recibido:', e);
    Livewire.dispatch('refresh'); // Actualiza componentes Livewire
});


