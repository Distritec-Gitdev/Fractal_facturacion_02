import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.js'],
            refresh: true,
        }),
    ],
    // 👇 Añade esta sección para exponer las variables de Pusher
   // vite.config.js
    define: {
        'import.meta.env.VITE_PUSHER_APP_KEY': JSON.stringify('local'), // 👈 Valor directo
        'import.meta.env.VITE_PUSHER_APP_CLUSTER': JSON.stringify('mt1'),
        'import.meta.env.VITE_PUSHER_HOST': JSON.stringify('127.0.0.1'),
        'import.meta.env.VITE_PUSHER_PORT': JSON.stringify(6001)
    }
});